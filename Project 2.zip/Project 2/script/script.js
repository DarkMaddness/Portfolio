function createModal(imgNum)
{
    var modal = () => `
    <div class="overlay">
        <div class="modal" onclick="removeModel()">
            <img src="images/portfolio-`+ imgNum + `.png" alt="portImg` + imgNum + `" >
            <button class="close-modal">
                X
            </button>
        </div>
    </div>
  `;
    const body = document.querySelector(`body`);
    document.querySelector("div.overlay") == null
    body.insertAdjacentHTML("beforebegin", modal());
    const button = document.querySelector(`button.close-modal`);
    button.addEventListener(`click`, removeModel);
}
function removeModel(e)
{
    const overlay = document.querySelector(`div.overlay`);
    overlay.remove()
}